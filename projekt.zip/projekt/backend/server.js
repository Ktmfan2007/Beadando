const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());


const dbFile = 'db.json';


app.get('/items', (req, res) => {
    const data = JSON.parse(fs.readFileSync(dbFile, 'utf-8'));
    res.json(data.items);
});

app.get('/items/:id', (req, res) => {
    const data = JSON.parse(fs.readFileSync(dbFile, 'utf-8'));
    const item = data.items.find(i => i.id === parseInt(req.params.id));
    if (item) res.json(item);
    else res.status(404).json({ error: 'Az elem nem található' });
});

app.post('/items', (req, res) => {
    const data = JSON.parse(fs.readFileSync(dbFile, 'utf-8'));
    const newItem = {
        id: data.items.length + 1,
        name: req.body.name,
        price: req.body.price
    };
    data.items.push(newItem);
    fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
    res.status(201).json(newItem);
});

app.put('/items/:id', (req, res) => {
    const data = JSON.parse(fs.readFileSync(dbFile, 'utf-8'));
    const index = data.items.findIndex(i => i.id === parseInt(req.params.id));
    if (index !== -1) {
        data.items[index] = {
            id: parseInt(req.params.id),
            name: req.body.name,
            price: req.body.price
        };
        fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
        res.json(data.items[index]);
    } else {
        res.status(404).json({ error: 'AZ elem nem található' });
    }
});

app.delete('/items/:id', (req, res) => {
    const data = JSON.parse(fs.readFileSync(dbFile, 'utf-8'));
    const index = data.items.findIndex(i => i.id === parseInt(req.params.id));
    if (index !== -1) {
        data.items.splice(index, 1);
        fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
        res.status(204).send();
    } else {
        res.status(404).json({ error: 'Az elem nem található' });
    }
});

app.listen(PORT, () => {
    console.log(`Szerver fut: http://localhost:${PORT}`);
});