document.addEventListener('DOMContentLoaded', () => {
    const itemList = document.getElementById('item-list');
    const form = document.getElementById('add-item-form');
    const itemName = document.getElementById('item-name');
    const itemPrice = document.getElementById('item-price');

    const updateId = document.getElementById('update-id');
    const updateName = document.getElementById('update-name');
    const updatePrice = document.getElementById('update-price');
    const updateButton = document.getElementById('update-item');

    const deleteId = document.getElementById('delete-id');
    const deleteButton = document.getElementById('delete-item');

    function getItems() {
        axios.get('http://localhost:3000/items')
            .then(response => {
                itemList.innerHTML = '';
                response.data.forEach(item => {
                    const li = document.createElement('li');
                    li.textContent = `${item.id}: ${item.name} - ${item.price} Ft`;
                    itemList.appendChild(li);
                });
            })
            .catch(error => console.error('Hiba:', error));
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const newItem = {
            name: itemName.value,
            price: Number(itemPrice.value)
        };
        axios.post('http://localhost:3000/items', newItem)
            .then(() => {
                itemName.value = '';
                itemPrice.value = '';
                getItems();
            })
            .catch(error => console.error('Hiba történt:', error));
    });

    updateButton.addEventListener('click', () => {
        const updatedItem = {
            name: updateName.value,
            price: Number(updatePrice.value)
        };
        axios.put(`http://localhost:3000/items/${updateId.value}`, updatedItem)
            .then(() => {
                updateId.value = '';
                updateName.value = '';
                updatePrice.value = '';
                getItems();
            })
            .catch(error => console.error('Hiba:', error));
    });


    deleteButton.addEventListener('click', () => {
        axios.delete(`http://localhost:3000/items/${deleteId.value}`)
            .then(() => {
                deleteId.value = '';
                getItems();
            })
            .catch(error => console.error('Hiba:', error));
    });

    getItems();
});